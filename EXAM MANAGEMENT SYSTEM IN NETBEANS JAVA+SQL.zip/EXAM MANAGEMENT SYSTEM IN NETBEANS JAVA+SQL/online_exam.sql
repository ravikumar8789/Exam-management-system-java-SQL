-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2023 at 09:28 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `UserAnswer` varchar(50) NOT NULL,
  `userName` varchar(15) NOT NULL,
  `QuestionName` varchar(200) NOT NULL,
  `RightAns` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`UserAnswer`, `userName`, `QuestionName`, `RightAns`) VALUES
('A', 'ravikr', 'What is the value of PI ?', 'A'),
('C', 'ravikr', 'what is the formula for area of circle ?', 'C'),
('A', 'ravikr', 'what is the sum of 5+8+9', 'A'),
('C', 'ravikr', 'what is the value of 8*5', 'C'),
('B', 'ravikr', '2+2/2', 'B'),
('C', 'ravikr', '50% of 100 ?', 'C'),
('A', 'ravikr', 'What is the value of PI ?', 'A'),
('C', 'ravikr', 'what is the formula for area of circle ?', 'C'),
('A', 'ravikr', 'what is the sum of 5+8+9', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `exam_schedule`
--

CREATE TABLE `exam_schedule` (
  `ExamTitle` varchar(20) NOT NULL,
  `ExamDate` date NOT NULL,
  `SubjectName` varchar(15) NOT NULL,
  `SubjectCode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_schedule`
--

INSERT INTO `exam_schedule` (`ExamTitle`, `ExamDate`, `SubjectName`, `SubjectCode`) VALUES
('End Term', '2023-04-13', 'DSA', 'CAP770'),
('End term', '2023-04-30', 'Maths', 'MTH403'),
('Mid sem', '2023-05-06', 'Java', 'CAP680'),
('End term', '2023-05-05', 'Hindi', 'CAP777'),
('Mid sem', '2023-05-01', 'java Lab', 'CAP990'),
('q', '2023-01-01', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('ravikumar', 'raviravi1'),
('admin', 'admin'),
('sendrela', 'sen1234'),
('kundan', '1234'),
('soumay', 'soumay'),
('shalini', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `question_fill`
--

CREATE TABLE `question_fill` (
  `Question` varchar(100) NOT NULL,
  `SubjectCode` varchar(20) NOT NULL,
  `OptionA` varchar(50) NOT NULL,
  `OptionB` varchar(50) NOT NULL,
  `OptionC` varchar(50) NOT NULL,
  `OptionD` varchar(50) NOT NULL,
  `RightAnswer` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_fill`
--

INSERT INTO `question_fill` (`Question`, `SubjectCode`, `OptionA`, `OptionB`, `OptionC`, `OptionD`, `RightAnswer`) VALUES
('What is the full form of DSA?', 'CAP770', 'Data structure and algorithms', 'Database structure and Algorithms', 'Data Structure and Algimer', 'Digital structure and Analysis', 'A'),
('What is the value of PI ?', 'MTH403', '3.144', '3.890', '67.222', '333.33', 'A'),
('what is the formula for area of circle ?', 'MTH403', 'pi*r*h', 'pi*r*r*r', 'pi*r*r', 'pi*h*base', 'C'),
('what is the sum of 5+8+9', 'MTH403', '22', '11', '65', '18', 'A'),
('what is the value of 8*5', 'MTH403', '45', '41', '40', '44', 'C'),
('2+2/2', 'MTH403', '2', '3', '4', '5', 'B'),
('50% of 100 ?', 'MTH403', '30', '40', '50', '60', 'C'),
('value of 0/2 ?', 'MTH403', '0', '1', '5', '4', 'A'),
('Value of 2/0 ?', 'MTH403', 'infinity', 'finite', '0', '-2', 'A'),
('area of square ?', 'MTH403', 'l*b*h', 'a*a*a', 'length*breadth', 'a*a', 'D'),
('20+45-98+36/67(288)*0', 'MTH403', 'cannot be determined', '0', '67', '89', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `FirstName` varchar(15) NOT NULL,
  `LastName` varchar(15) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `susername` varchar(20) NOT NULL,
  `spassword` varchar(20) NOT NULL,
  `CollageName` varchar(50) NOT NULL,
  `EmailId` varchar(30) NOT NULL,
  `ContactNo` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`FirstName`, `LastName`, `Gender`, `susername`, `spassword`, `CollageName`, `EmailId`, `ContactNo`) VALUES
('Ravi', 'kumar', 'Male', 'ravikr', 'raviravi1', 'Lovely PU', 'ravikumar9006997@gmail.com', '8789592302'),
('Soumay', 'Thakur', 'Male', 'soumay1', '1234', 'LPU', 'soumaydoorservice@gmail.com', '8976578736'),
('sendrela', 'gulzar', 'Female', 'sendrelag', '1234', 'LPU', 'sendrelagulzar@gmail.com', '8963913367'),
('Kundan', 'kumar', 'Male', 'kundan1', 'kundankundan1', 'LPU', 'kundan@gmail.com', '6239426363'),
('deepika', 'kumari', 'Female', 'deepak', 'deepak1', 'LPU', 'deepak@gmail.com', '876767677'),
('Puneet ', 'sharma', 'Male', 'puneet', '1234', 'LPU', 'puneetsharma@gmail.com', '8871326599'),
('Satish', 'kumar', 'Female', 'satishkumar', '1234', 'LPU', 'satish@gmail.com', '68767868767'),
('Gaurav', 'kumar', 'Male', 'gaurav', '1234', 'LPU', 'gaurav@gmial.com', '7876767868');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
